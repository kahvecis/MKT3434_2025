"""
README
------
# 20067050 - Machine Learning Course GUI

## Content

- User-friendly PyQt6 based GUI with:
- Classic ML algorithms (Regression, Classification)
- MLP, CNN, RNN architectures (add/remove layers, dropout, L2, optimizer selection, scheduler)
- Image augmentation options
- Transfer learning with pre-trained model (VGG16, ResNet50)
- GAN (Generative Adversarial Network) training and real-time log
- Visualization of training curves and weight gradient histogram
- Model saving/loading (.h5/.json)
- Test metrics (accuracy, F1-score, MSE) and confusion matrix

---

## Requirements

Python 3.8+
The following libraries must be installed:
pip install numpy pandas matplotlib scikit-learn pyqt6 tensorflow plotly umap-learn

---

## Usage

1. **Run:**
python 20067050.py

2. **Data Loading:**
- Load a ready dataset or your own CSV file from the "Data Management" section.
- Set the scaling and test/train ratio.

3. **Model Design and Training:**
- Create your architecture from the relevant tab (MLP, CNN, RNN, GAN).
- Add/remove layers, select optimizer and scheduler, check augmentation options.
- Start training by clicking the "Train" button.

4. **GAN Training:**
- Switch to the "GAN" tab, click the "Train Simple GAN (MNIST)" button.
- Logs are instantly visible on the screen during training.

5. **Results and Recording:**
- Training curves, weight gradient histogram and metrics are displayed in GUI.
- You can save/load the model as ".h5" or ".json".

---

## Features

- **Layer Design:** Add/remove layers and their parameters from GUI.
- **Optimizer/Scheduler:** Adam, SGD, RMSprop and Step/Exponential Decay support.
- **Augmentation:** Rotation, flip, zoom options.
- **Transfer Learning:** Fine-tune your own data with VGG16/ResNet50.
- **GAN:** ​​Simple GAN training and real-time log.
- **Real-time Log:** Epoch logs and GAN logs are displayed instantly during training.
- **Metrics:** Accuracy, F1-score, MSE, confusion matrix.
- **Save/Load Model:** Save the trained model or architecture save/load.

---

## Notes

- All operations can be done interactively via GUI.
- If you get an error, you can see the error message in GUI.
- For screenshots and architectural explanations, please see `20067050.pdf` file.

---

**Prepared by:**
20067050
"""
